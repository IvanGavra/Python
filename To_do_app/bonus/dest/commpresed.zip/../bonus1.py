text = input("Enter a tittle:")
lenght = len(text)

print("title lenght is:", lenght)
